import java.util.*;
import java.io.*;

public class c {
	static int len;
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		input.nextLine();

		String[] words = new String[n];
		for (int i = 0; i < n; i++) words[i] = input.nextLine();
		len = words[0].length();

		// compute adjacencies.
		List<List<Integer>> adj = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			List<Integer> res = new ArrayList<>();
			for (int j = i + 1; j < n; j++) {

			}
			adj.add(new ArrayList<>());
		}
	}

	public static boolean adj(String first, String second) {
		int diffs = 0;
		for (int i = 0; i < len; i++) {
			if (first.charAt(i) != second.charAt(i)) diffs++;
		}

		return diffs == 2;
	}
}
