import math

n = int(input())

c = []
sumt = 0
total = 0.0
c = [int(x) for x in input().split(" ")]
f = { x: c.count(x) for x in c }
for x in f:
    count = f[x]
    for i in range(1, count+1):
        total -= math.log10(i)

for x in c:
    for j in range(1, x+1):
        total -= math.log10(j)
    sumt += x

for i in range(365-n+1,366):
    total += math.log10(i)

for i in range(1, sumt+1):
    total += math.log10(i)

print(total - math.log10(365)*sumt)
