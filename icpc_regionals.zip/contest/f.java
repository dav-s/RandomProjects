import java.util.*;
import java.io.*;

public class f {
	static int R;
	static int C;
	static boolean[][] matrix;

	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		R = input.nextInt();
		C = input.nextInt();
		input.nextLine();

		matrix = new boolean[R*2][C*2];
		for (int r = 0; r < R; r++) {
			String line = input.nextLine();
			for (int c = 0; c < C; c++) {
				char ch = line.charAt(c);

				if (ch == '/') {
					matrix[2*r+1][2*c] = true;
					matrix[2*r][2*c+1] = true;
				} else if (ch == '\\') {
					matrix[2*r][2*c] = true;
					matrix[2*r+1][2*c+1] = true;
				}
			}
		}

		/*
		for (int r = 0; r < 2*R; r++) {
			for (int c = 0; c < 2*C; c++) {
				System.out.print(matrix[r][c] ? '#' : '.');
			}
			System.out.println();
		}
		*/

		for (int r = 0; r < 2*R; r++) {
			flood(r, 0);
			flood(r, 2*C-1);
		}

		for (int c = 0; c < 2*C; c++) {
			flood(0, c);
			flood(2*R-1, c);
		}

		int count = 0;
		for (int r = 1; r < 2*R-1;r++) {
			for (int c = 1; c < 2*C-1; c++) {
				if (!matrix[r][c] && !flood(r, c)) count++;
			}
		}

		System.out.println(count);
	}

	static int[] DR = { -1, 1, 0, 0 };
	static int[] DC = { 0, 0, -1, 1 };

	public static boolean flood(int r, int c) {
		Queue<Point> check = new ArrayDeque<>();
		check.add(new Point(r, c));

		boolean result = false;
		while (!check.isEmpty()) {
			Point next = check.poll();
			if (next.r < 0 || next.c < 0 || next.r >= 2*R || next.c >= 2*C) {
				result = true;
				continue;
			}

			if (matrix[next.r][next.c]) continue;
			matrix[next.r][next.c] = true;

			for (int d = 0; d < 4; d++) {
				Point pr = new Point(next.r + DR[d], next.c + DC[d]);
				check.add(pr);
			}
		}

		return result;
	}

	public static class Point {
		public int r, c;

		public Point(int r, int c) { this.r = r; this.c = c; }

		@Override
		public int hashCode() { return (r << 16) | c; }

		@Override
		public boolean equals(Object other) {
			Point p = (Point) other;
			return r == p.r && c == p.c;
		}
		@Override
			public String toString() { return r + " " + c; }
	}
}
