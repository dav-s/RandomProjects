import java.util.*;
import java.io.*;

public class d {
    public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();

		int[] times = new int[43300];
		for( int i = 0; i < n; i++ ){
			int d = in.nextInt(), t = in.nextInt();
			times[t]++;
			times[t - d]++;
			times[t - 2*d]++;
		}
		
		int max = -1;
		for( int i = 0; i < 43300; i++)
			max = Math.max(max,(times[i]+1)/2);

		System.out.println(max);
	}
}
