import java.io.*;
import java.util.*;

public class h {
	public static void main(String[] args) throws Exception {
		Scanner input = new Scanner(System.in);
		int m = input.nextInt();
		TreeMap<Integer, Integer> sums = new TreeMap<>();

		long total = 0;
		for (int i = 0; i < m; i++) {
			int num = input.nextInt();
			if (!sums.containsKey(num)) sums.put(num, 0);
			sums.put(num, sums.get(num) + 1);

			total += num;
		}

		// figure out crossing point.
		long prefix = 0L;
		for (Map.Entry<Integer, Integer> entry : sums.entrySet()) {
			prefix += entry.getKey() * entry.getValue();

			if (prefix > total/2) {
				System.out.println(entry.getKey());
				return;
			} else if (prefix == total/2) {
				System.out.println(entry.getKey()+1);
				return;
			}
		}
	}
}
