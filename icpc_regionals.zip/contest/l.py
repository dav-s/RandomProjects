import math
n = int(input())

p = []
for i in range(n):
    p.append([float(c) for c in input().split()])

def dist(x,y):
    x1, x2 = x
    y1, y2=y
    return math.sqrt((x1-y1)**2+(x2-y2)**2)
def perp(p):
    x, y = p
    return (-y,x)
def cross(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return x1*y2 - x2*y1
def add(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return (x1+x2, y1+y2)
def sub(p1, p2):
    x1, y1 = p1
    x2, y2 = p2
    return (x1-x2, y1-y2)
def mult(p1, a):
    x1, y1 = p1
    return (x1*a, y1*a)
def dist2(p):
    x,y=p
    return x*x+y*y
def ccircle(A,B,C):
    b = sub(C,A)
    c=sub(B,A)
    return add(A, mult(perp(sub(mult(b, dist2(c)), mult(c, dist2(b)))), 1/cross(b,c)/2)) 

def rad(ps):
    r = 0
    o = ps[0]
    eps = 1+1e-8
    for i in range(n):
        if (dist(o, ps[i]))>r*eps:
            o = ps[i]
            r=0
            for j in range(i):
                if(dist(o,ps[j]))>r*eps:
                    o=mult(add(ps[i],ps[j]),.5)
                    r = dist(o, ps[i])
                    for k in range(j):
                        if(dist(o, ps[k]))> r*eps:
                            o = ccircle(ps[i],ps[j],ps[k])
                            r=dist(o, ps[i])
    return r


print(2*min([
        rad([(p[i][0],p[i][1]) for i in range(n)]),
        rad([(p[i][0],p[i][2]) for i in range(n)]),
        rad([(p[i][1],p[i][2]) for i in range(n)])
]))
    
