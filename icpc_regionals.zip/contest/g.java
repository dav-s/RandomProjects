import java.io.*;
import java.util.*;

public class g {
	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt(), m = input.nextInt();

		Map<Integer, List<Integer>> graph = new HashMap<>();
		for (int i = 0; i < m; i++) {
			int a = input.nextInt(), b = input.nextInt();
			if (!graph.containsKey(a)) graph.put(a, new ArrayList<>());
			if (!graph.containsKey(b)) graph.put(b, new ArrayList<>());

			graph.get(a).add(b);
			graph.get(b).add(a);
		}

		Set<Integer> visited = new HashSet<>();
		Queue<State> queue = new ArrayDeque<>();

		queue.add(new State(1, 0));

		List<Integer> EMPTY = new ArrayList<>();

		while (!queue.isEmpty()) {
			State next = queue.poll();

			if (next.node == n) {
				System.out.println(next.distance - 1);
				return;
			}

			if (visited.contains(next.node)) continue;
			visited.add(next.node);

			for (int adj : graph.getOrDefault(next.node, EMPTY)) {
				queue.add(new State(adj, next.distance + 1));
			}
		}
	}

	public static class State {
		public int node;
		public int distance;

		public State(int n, int d) {
			this.node = n;
			this.distance = d;
		}
	}
}

