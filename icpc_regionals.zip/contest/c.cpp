#include <iostream>
#include <string>
#include <bits/stdc++.h>

using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); i++)
#define trav(a, x) for(auto& a: x)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

bool find(int j, vector<vi>& g, vi& btoa, vi& vis) {
	if (btoa[j] == -1) return 1;
	vis[j] = 1; int di = btoa[j];
	trav(e, g[di]) {
		if (!vis[e] && find(e, g, btoa, vis)) {
			btoa[e] = di;
			return 1;
		}
	}
	return 0;
}

int dfsMatching(vector<vi>& g, vi& btoa) {
	vi vis;
	rep(i, 0, sz(g)) {
		vis.assign(sz(btoa), 0);
		trav(j, g[i]) {
			if (find(j, g, btoa, vis)) {
				btoa[j] = i;
				break;
			}
		}
	}
	return sz(btoa) - (int)count(all(btoa), -1);
}

vi cover(vector<vi>& g, int n, int m) {
	vi match(m, -1);
	int res = dfsMatching(g, match);
	vector<bool> lfound(n, true), seen(m);
	trav(it, match) if (it != -1) lfound[it] = false;
	vi q, cover;
	rep(i, 0, n) if (lfound[i]) q.push_back(i);
	while(!q.empty()) {
		int i = q.back(); q.pop_back();
		lfound[i] = 1;
		trav(e, g[i]) if (!seen[e] && match[e] != -1) {
			seen[e] = true;
			q.push_back(match[e]);
		}
	}
	rep(i,0,n) if (!lfound[i]) cover.push_back(i);
	rep(i,0,m) if (seen[i]) cover.push_back(n+i);
	return cover;
}

bool adj(std::string& first, std::string& second) {
	int d = 0;
	for (int i = 0; i < sz(first); i++) {
		if (first[i] != second[i]) d++;
	}

	return d == 2;
}

void split(int node, bool color, vi& vis, vector<vi>& g, vi& first, vi& second) {
	if (vis[node]) return;
	vis[node] = 1;

	if (color) second.push_back(node);
	else first.push_back(node);

	for (auto& a : g[node]) {
		split(a, !color, vis, g, first, second);
	}
}

int main() {
	int n;
	cin >> n;
	std::string strings[n];
	for (int i = 0; i < n; i++) cin >> strings[i];

	// compute pairwise adjacencies.
	vector<vi> graph(n);
	for (int i = 0; i < n; i++) {
		for(int j = i + 1; j < n; j++) {
			if (adj(strings[i], strings[j])) {
				graph[i].push_back(j);
				graph[j].push_back(i);
			}
		}
	}

	// split into a bipartite graph
	vi left;
	vi right;
	vi vis(n);
	for(int i = 0; i < n; i++) vis[i] = 0;
	for (int i = 0; i < n; i++) split(i, false, vis, graph, left, right);

	// fix indexes
	unordered_map<int, int> rightindexes;
	for(int i = 0; i < sz(right); i++) {
		rightindexes[right[i]] = i;
	}

	// adjacency graph for left side.
	vector<vi> left_graph(sz(left));
	for (int i = 0; i < sz(left); i++) {
		vi result(sz(graph[left[i]]));
		for (int j = 0; j < sz(graph[left[i]]); j++) {
			int rightv = graph[left[i]][j];
			result.push_back(sz(left)+rightindexes[rightv]);
		}
		left_graph.push_back(result);
	}

	vi cv = cover(left_graph, sz(left), sz(right));

	vi btoa(sz(right), -1);
	cout << dfsMatching(left_graph, btoa) << endl;
}

