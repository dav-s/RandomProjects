n = int(input())

t = [int(s) for s in input().split()]

e = [[] for i in range(n)]

for i in range(n-1):
    u, v, w = [int(s) for s in input().split()]
    e[u-1].append((v-1,w))
    e[v-1].append((u-1,w))

count = [0]*n
total = [0]*n

getctv = [False] * n
getctq = [(0,-1,0, 1, t[0])]
while len(getctq) > 0:
    p, last, pos, myc, myt = getctq.pop()
    cont = False
    for i in range(pos, len(e[p])):
        c,w = e[p][i]
        if c == last:
            continue
        if getctv[c] == False:
            getctq.append((p, last, i, myc, myt))
            getctq.append((c, p, 0, 1, t[c]))
            cont = True
            break
        else:
            myc += count[c]
            myt += total[c]
    if cont:
        continue
    count[p] = myc
    total[p] = myt
    getctv[p] = True

calv = [-1] * n
calq = [(0,-1,0,0, 0, 0)]

while len(calq) > 0:
    p,last,l,pos,myself,myother = calq.pop()
    cont = False
    for i in range(pos, len(e[p])):
        c,w = e[p][i]
        if c==last:
            continue
        if calv[c] == -1:
            calq.append((p, last, l,i,myself,myother))
            calq.append((c, p, l+w, 0,0,0))
            cont = True
            break
        else:
            s, o = calv[c]
            myself += s
            myother += o
    if cont:
        continue
    myself += l*t[0]
    myother += l*t[p]
    calv[p] = [myself, myother]

vals = [[-1, -1] for i in range(n)]
vals[0] = calv[0]
updateq = [(0, -1)]

while len(updateq)>0:
    p, last = updateq.pop()
    self = vals[p][0]//t[p]
    other = vals[p][1]
    for (c, w) in e[p]:
        if c != last:
            vals[c][0] = (self+(n-2*count[c])*w)*t[c]
            vals[c][1] = other+(total[0]-2*total[c])*w
            updateq.append((c,p))

#print(count)
#print(total)
#print(vals)

for i in range(n):
    print(vals[i][0] + vals[i][1])
