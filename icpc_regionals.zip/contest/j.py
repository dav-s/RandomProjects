n = int(input())

g = []
for i in range(n):
    g.append([c for c in input()])

for row in g:
    w= 0
    b =0
    for i in range(2,n):
        if row[i] == row[i-1] == row[i-2]:
            print("0")
            quit()
    for c in row:
        if c=='W':
            w+=1
        else:
            b+=1
    if w!=b:
        print("0")
        quit()

for j in range(n):
    row = [row[j] for row in g]
    w= 0
    b =0
    for i in range(2,n):
        if row[i] == row[i-1] == row[i-2]:
            print("0")
            quit()
    for c in row:
        if c=='W':
            w+=1
        else:
            b+=1
    if w!=b:
        print("0")
        quit()

print("1")
